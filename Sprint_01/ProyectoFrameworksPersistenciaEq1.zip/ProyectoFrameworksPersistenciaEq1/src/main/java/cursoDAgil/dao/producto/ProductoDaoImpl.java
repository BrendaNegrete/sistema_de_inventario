/*
 * EQUIPO 01
 * AUTOR: ALEJANDRA LOPEZ ROJAS
 */
package cursoDAgil.dao.producto;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import cursoDAgil.bd.domain.Productos;
import cursoDAgil.bd.mappers.ProductosMapper;

@Named 
public class ProductoDaoImpl implements ProductoDao, Serializable{	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6492318751376356446L;
	SqlSession sqlSession;

	@Autowired
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession=sqlSession;
	}
	
	@Override
	public Integer nuevoProducto(Productos producto) {
		try {
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			System.out.println("Producto Registrado!");

			System.out.println("\tNombre del Producto: " + producto.getNombre() );
			System.out.println("\tPrecio: " + producto.getPrecio());
			System.out.println("\tPrecio Venta: " + producto.getPrecioVta());
			System.out.println("\tCantidad: " + producto.getCantidad());
			System.out.println("\tMarca Id: " + producto.getMarcaId());
			
			return productosMapper.nuevoProducto(producto);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	
	/*public void eliminarProducto(Integer idProducto) {
		
			 sqlSession.delete("Test.class", idProducto);
			 sqlSession.commit();
			 
	}*/
	@Override
	public Integer eliminarProdcuto(Map<String, Integer> mapProductos) {
		try {
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			System.out.println("Producto Eleminado!");
			System.out.println("Producto eliminado: "+mapProductos);
			return productosMapper.eliminarProducto(mapProductos);
			
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public Integer modificarProducto(Productos producto) {
		try {
			ProductosMapper productosMapper = sqlSession.getMapper(ProductosMapper.class);
			System.out.println("Producto Modificado!");
			
			System.out.println("\tNombre del Producto: " + producto.getNombre() );
			System.out.println("\tPrecio: " + producto.getPrecio());
			System.out.println("\tPrecio Venta: " + producto.getPrecioVta());
			System.out.println("\tCantidad: " + producto.getCantidad());
			System.out.println("\tMarca Id: " + producto.getMarcaId());
			
			return productosMapper.modificarProducto(producto);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public List<Productos> listarProductos(){
		List<Productos> list=null;
		try {
			ProductosMapper ProductosMapper= sqlSession.getMapper(ProductosMapper.class);
			list= ProductosMapper.listarProductos();
			return list;
		}catch(Exception e) {
			System.out.println("Error:   "+ e);
		}
		return null;
	}
	@Override
	public List<Productos> listarProductosYmarcas(){
		List<Productos> list=null;
		try {
			ProductosMapper ProductosMapper= sqlSession.getMapper(ProductosMapper.class);
			list= ProductosMapper.listarProductosYmarcas();
			return list;
		}catch(Exception e) {
			System.out.println("Error:   "+ e);
		}
		return null;
	}
	
	
	@Override
	public Productos obtenerProductoPorId(Map<String, Integer> mapProductos) {
		try {
			ProductosMapper ProductosMapper = sqlSession.getMapper(ProductosMapper.class);
			return ProductosMapper.obtenerProductoPorId(mapProductos);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public Productos consultaProductoPorIdmosrarMarca(Map<String, Integer> mapProductos) {
		try {
			ProductosMapper ProductosMapper = sqlSession.getMapper(ProductosMapper.class);
			return ProductosMapper.consultaProductoPorIdmosrarMarca(mapProductos);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}	
}