/*
 * EQUIPO 01
 * AUTOR: DAVID GERMAN CASTRO ORTIIZ
 */
package cursoDAgil.dao.venta;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import cursoDAgil.bd.domain.Ventas;
import cursoDAgil.bd.mappers.VentaMapper;

@Named
public class VentaDaoImpl implements VentaDao, Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3998128515896860098L;
	SqlSession sqlSession;
	
	@Autowired
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	@Override
	public List <Ventas> listarTodasVentas(){
		List <Ventas> list = null;
		try {
			VentaMapper ventaMapper = sqlSession.getMapper(VentaMapper.class);
			list = ventaMapper.listarTodasVentas();
			return list;
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public Ventas obtenerVentaPorId(Map<String, Integer> mapVenta) {
		try {
			VentaMapper ventaMapper = sqlSession.getMapper(VentaMapper.class);
			return ventaMapper.obtenerVentaPorId(mapVenta);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public List <Ventas> obtenerVentasPorCliente(Map<String, String> MapCliente) {
		List <Ventas> list = null;
		try {
			VentaMapper ventaMapper = sqlSession.getMapper(VentaMapper.class); 
			list = ventaMapper.obtenerVentasPorCliente(MapCliente);
			return list;
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public Integer nuevaVenta(Ventas venta) {
		try {
			VentaMapper ventaMapper = sqlSession.getMapper(VentaMapper.class);
			System.out.println("Venta creada con éxito!");
			return ventaMapper.nuevaVenta(venta);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
}