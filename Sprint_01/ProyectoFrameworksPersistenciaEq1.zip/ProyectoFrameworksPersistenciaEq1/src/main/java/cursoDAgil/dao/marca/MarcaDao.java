/*
 * EQUIPO 01
 * AUTOR: BRENDA NEGRETE SANCHEZ
 */
package cursoDAgil.dao.marca;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Marca;

public interface MarcaDao {
	List <Marca> obtenerMarcas();
	Integer nuevaMarca(Marca marca);
	Marca obtenerMarca(Map<String, Integer> mapMarca);
	Integer eliminarMarca(Map<String, Integer> mapMarca);
	Integer cambiarMarca(Marca marca);
}