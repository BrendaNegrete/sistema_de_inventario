/*
 * EQUIPO 01
 * AUTOR: ARMANDO VENTURA DOMINGUEZ
 */
package cursoDAgil.dao.cliente;

import cursoDAgil.bd.domain.Cliente;
import cursoDAgil.bd.mappers.ClienteMapper;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Named;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

@Named
public class ClienteDaoImpl implements ClienteDao, Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2996238527625357987L;
	SqlSession sqlSession;
	
	@Autowired
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}

	@Override
	public List<Cliente> listarClientes() {
		try {
			ClienteMapper clienteMapper = sqlSession.getMapper(ClienteMapper.class);
			return clienteMapper.listarClientes();
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public Integer eliminarCliente(Map<String, Integer> mapCliente) {
		try {
			ClienteMapper clienteMapper = sqlSession.getMapper(ClienteMapper.class);
			return clienteMapper.eliminarCliente(mapCliente);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public Integer insertarCliente(Cliente cliente) {
		try {
			ClienteMapper clienteMapper = sqlSession.getMapper(ClienteMapper.class);
			return clienteMapper.insertarCliente(cliente);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public Integer actualizarCliente(Cliente cliente) {
		try {
			ClienteMapper clienteMapper = sqlSession.getMapper(ClienteMapper.class);
			return clienteMapper.actualizarCliente(cliente);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public Cliente obtenerClientePorId(Map<String, Integer> mapCliente) {
		try {
			ClienteMapper clienteMapper = sqlSession.getMapper(ClienteMapper.class);
			return clienteMapper.obtenerClientePorId(mapCliente);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public List<Cliente> listarClientesDireccion() {
		List <Cliente> list = null;
		try {
			ClienteMapper clienteMapper = sqlSession.getMapper(ClienteMapper.class);
			list = clienteMapper.listarClientesDireccion();
			return list;
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}

	@Override
	public Cliente obtenerClienteDireccionPorId(Map<String, Integer> mapCliente) {
		try {
			ClienteMapper clienteMapper = sqlSession.getMapper(ClienteMapper.class);
			return clienteMapper.obtenerClienteDireccionPorId(mapCliente);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
}
