/*
 * EQUIPO 01
 * AUTOR: BRENDA NEGRETE SANCHEZ
 */
package cursoDAgil.dao.marca;

import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import cursoDAgil.bd.domain.Marca;
import cursoDAgil.bd.mappers.MarcaMapper;

@Named
public class MarcaDaoImpl implements MarcaDao{
	SqlSession sqlSession;
	@Autowired
	public void setSqlSession (SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	@Override
	public Integer nuevaMarca(Marca marca) {
		try {
			MarcaMapper marcaMapper = sqlSession.getMapper(MarcaMapper.class);
			System.out.println("Dirección creada con éxito!");
			return marcaMapper.nuevaMarca(marca);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public Marca obtenerMarca(Map<String, Integer> mapMarca) {
		try {
			MarcaMapper marcaMapper = sqlSession.getMapper(MarcaMapper.class);
			return marcaMapper.obtenerMarca(mapMarca);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	
	@Override
	public List<Marca> obtenerMarcas() {
		try {
			MarcaMapper marcaMapper = sqlSession.getMapper(MarcaMapper.class);
			return marcaMapper.obtenerMarcas();
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public Integer eliminarMarca(Map<String, Integer> mapMarca) {
		try {
			MarcaMapper marcaMapper = sqlSession.getMapper(MarcaMapper.class);
			return marcaMapper.eliminarMarca(mapMarca);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
	@Override
	public Integer cambiarMarca(Marca marca) {
		try {
			MarcaMapper marcaMapper = sqlSession.getMapper(MarcaMapper.class);
			System.out.println("Marca Cambiada!");
			return marcaMapper.cambiarMarca(marca);
		}catch (Exception e) {
			System.out.println("Error: " + e);
		}
		return null;
	}
}