/*
 * EQUIPO 01
 * AUTOR: DAVID GERMAN CASTRO ORTIZ
 */
package cursoDAgil.dao.ganancia;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import cursoDAgil.bd.domain.Ganancia;
import cursoDAgil.bd.mappers.GananciaMapper;



@Named
public class GananciaDaoImpl implements GananciaDao, Serializable{
	private static final long serialVersionUID = -6456965766968902300L;
	SqlSession sqlSession;
	@Autowired
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	@Override
	
	public List<Ganancia> listarGanancia() {
		// TODO Auto-generated method stub
		List<Ganancia> list = null;
		try {
			GananciaMapper gananciaMapper = sqlSession.getMapper(GananciaMapper.class);
			list = gananciaMapper.listarGanancia();
			for(Ganancia c:list) {
				System.out.println("\tID ganancia: "+ c.getIdGanancia());
				System.out.println("\tID venta: "+c.getVentaId());
				System.out.println("\tTotal ganancia: "+c.getTotalGanancia());
				System.out.println("\tFecha: "+c.getFecha());
				System.out.println();
			}
			return list;
		}catch(Exception e){
			System.out.println("Error: "+ e);
		}
		return null;
	}
	
	public Ganancia listarPorFecha(Map <String, String> mapGanancia) {
		try {
			GananciaMapper gananciaMapper = sqlSession.getMapper(GananciaMapper.class);
			Ganancia ganancia = new Ganancia();
			ganancia = gananciaMapper.listarPorFecha(mapGanancia);
			return ganancia;
		}catch(Exception e) {
			System.out.println("Error: "+e);
		}
		return null;
	}

}