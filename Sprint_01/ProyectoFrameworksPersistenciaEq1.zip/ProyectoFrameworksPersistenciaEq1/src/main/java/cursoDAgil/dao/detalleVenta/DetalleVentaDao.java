/*
 * EQUIPO 01
 * AUTOR: DAVID GERMAN CASTRO ORTIZ
 */
package cursoDAgil.dao.detalleVenta;

import java.util.List;

import cursoDAgil.bd.domain.DetalleVenta;

public interface DetalleVentaDao {
	List<DetalleVenta> listarTodosDetalleVentas();
}