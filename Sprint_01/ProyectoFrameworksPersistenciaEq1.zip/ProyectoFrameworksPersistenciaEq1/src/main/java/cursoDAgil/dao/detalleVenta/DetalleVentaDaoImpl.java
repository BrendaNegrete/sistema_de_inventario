/*
 * EQUIPO 01
 * AUTOR: DAVID GERMAN CASTRO ORTIZ
 */
package cursoDAgil.dao.detalleVenta;

import java.io.Serializable;
import java.util.List;

import javax.inject.Named;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import cursoDAgil.bd.domain.DetalleVenta;
import cursoDAgil.bd.mappers.DetalleVentaMapper;

@Named
public class DetalleVentaDaoImpl implements DetalleVentaDao, Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6059883913180541863L;
	
	SqlSession sqlSession;
	@Autowired
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	@Override
	public List<DetalleVenta> listarTodosDetalleVentas() {
		List<DetalleVenta> list = null;
		try {
			DetalleVentaMapper detalleVentaMapper = sqlSession.getMapper(DetalleVentaMapper.class);
			list = detalleVentaMapper.listarTodosDetalleVentas();
			return list;
		}catch (Exception e) {
			System.out.println("Error: "+ e);
		}
		return null;
	}
	
}