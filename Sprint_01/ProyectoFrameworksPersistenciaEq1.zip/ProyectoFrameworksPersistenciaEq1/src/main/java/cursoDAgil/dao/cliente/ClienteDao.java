/*
 * EQUIPO 01
 * AUTOR: ARMANDO VENTURA DOMINGUEZ
 */
package cursoDAgil.dao.cliente;

import cursoDAgil.bd.domain.Cliente;
import java.util.List;
import java.util.Map;

public interface ClienteDao {
	List<Cliente> listarClientes();
	Integer eliminarCliente(Map<String, Integer> mapCliente);
	Integer insertarCliente(Cliente cliente);
	Integer actualizarCliente(Cliente cliente);
	Cliente obtenerClientePorId(Map<String, Integer> mapCliente);
	List<Cliente> listarClientesDireccion();
	Cliente obtenerClienteDireccionPorId(Map<String, Integer> mapCliente);
}
