/*
 * EQUIPO 01
 * AUTOR: ALEJANDRA LOPEZ ROJAS
 */
package cursoDAgil.dao.producto;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Productos;

public interface ProductoDao {
	List <Productos> listarProductos();
	Integer nuevoProducto(Productos producto);
	Integer eliminarProdcuto(Map<String, Integer> mapProductos);
	Integer modificarProducto(Productos producto);
	Productos obtenerProductoPorId(Map<String, Integer> mapProductos);
	List<Productos> listarProductosYmarcas();
	Productos consultaProductoPorIdmosrarMarca(Map<String, Integer> mapProductos);
}
