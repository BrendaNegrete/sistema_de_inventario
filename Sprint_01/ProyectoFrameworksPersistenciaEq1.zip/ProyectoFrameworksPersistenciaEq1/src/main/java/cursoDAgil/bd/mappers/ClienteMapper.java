/*
 * EQUIPO 01
 * AUTOR: ARMANDO VENTURA DOMINGUEZ
 */
package cursoDAgil.bd.mappers;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Cliente;

public interface ClienteMapper {
	List<Cliente> listarClientes();
	Integer eliminarCliente(Map<String, Integer> mapCliente);
	Integer insertarCliente(Cliente cliente);
	Integer actualizarCliente(Cliente cliente);
	Cliente obtenerClientePorId(Map<String, Integer> mapCliente);
	List<Cliente> listarClientesDireccion();
	Cliente obtenerClienteDireccionPorId(Map<String, Integer> mapCliente);
}