/*
 * EQUIPO 01
 * AUTOR: DAVID GERMAN CASTRO ORTIIZ
 */
package cursoDAgil.bd.mappers;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Ventas;

public interface VentaMapper {
	List <Ventas> listarTodasVentas();
	Ventas obtenerVentaPorId(Map<String, Integer> mapVenta);
	List <Ventas> obtenerVentasPorCliente(Map<String, String> mapVenta);
	Integer nuevaVenta(Ventas venta);
}