/*
 * EQUIPO 01
 * AUTOR: ALEJANDRA LOPEZ ROJASW
 */
package cursoDAgil.bd.mappers;

import java.util.List;
import java.util.Map;

import cursoDAgil.bd.domain.Productos;

public interface ProductosMapper {
	List<Productos> listarProductos();
	Integer nuevoProducto(Productos producto);
	Integer eliminarProducto(Map<String, Integer> mapProductos);
	Integer modificarProducto(Productos producto);
	Productos obtenerProductoPorId(Map<String, Integer> mapProductos);
	List<Productos> listarProductosYmarcas();
	Productos consultaProductoPorIdmosrarMarca(Map<String, Integer> mapProductos);
}
