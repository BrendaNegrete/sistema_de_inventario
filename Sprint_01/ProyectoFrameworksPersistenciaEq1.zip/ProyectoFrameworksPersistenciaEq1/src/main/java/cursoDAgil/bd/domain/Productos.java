/*
 * EQUIPO 01
 * AUTOR: ALEJANDRA LOPEZ ROJAS
 */
package cursoDAgil.bd.domain;

public class Productos {
	private Integer idProducto;
	private String nombre;
	private Double precio;
	private Double precioVta;
	private Integer cantidad;
	private Integer marcaId;
	private Marca marca;
	
	public Productos() {
		setMarca(new Marca());
	}
	public Marca getMarca() {
		return marca;
	}
	public void setMarca(Marca marca) {
		this.marca = marca;
	}
	
	public Integer getIdProducto() {
		return idProducto;
	}
	public void setIdProducto(Integer idProducto) {
		this.idProducto = idProducto;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public double getPrecioVta() {
		return precioVta;
	}
	public void setPrecioVta(double precioVta) {
		this.precioVta = precioVta;
	}
	public Integer getCantidad() {
		return cantidad;
	}
	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}
	public Integer getMarcaId() {
		return marcaId;
	}
	public void setMarcaId(Integer marcaId) {
		this.marcaId = marcaId;
	}
}