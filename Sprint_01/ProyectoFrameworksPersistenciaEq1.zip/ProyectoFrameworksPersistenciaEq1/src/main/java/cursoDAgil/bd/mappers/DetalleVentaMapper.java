/*
 * EQUIPO 01
 * AUTOR: DAVID GERMAN CASTRO ORTIZ
 */
package cursoDAgil.bd.mappers;

import java.util.List;

import cursoDAgil.bd.domain.DetalleVenta;

public interface DetalleVentaMapper {
	List <DetalleVenta> listarTodosDetalleVentas();
}