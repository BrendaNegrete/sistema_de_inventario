/*
 * EQUIPO 01
 * AUTOR: BRENDA NEGRETE SANCHEZ
 */
package cursoDAgil.bd.domain;

public class Marca {
	private Integer idMarca;
	private String nombreMarca;
	
	public Integer getIdMarca() {
		return idMarca;
	}
	public void setIdMarca(Integer idMarca) {
		this.idMarca = idMarca;
	}
	public String getNombreMarca() {
		return nombreMarca;
	}
	public void setNombreMarca(String nombreMarca) {
		this.nombreMarca = nombreMarca;
	}
}