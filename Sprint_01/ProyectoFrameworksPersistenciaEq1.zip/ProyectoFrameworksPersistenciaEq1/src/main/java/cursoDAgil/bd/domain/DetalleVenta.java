/*
 * EQUIPO 01
 * AUTOR: DAVID GERMAN CASTRO ORTIZ
 */
package cursoDAgil.bd.domain;

public class DetalleVenta {
	private Integer ventaId;
	private Integer productoId;
	private Integer cantidad;	
	private Productos producto;
	
	public DetalleVenta(){
		 setProducto(new Productos());
		}
	
	public Productos getProductos() {
		return producto;
	}
	public void setProducto(Productos producto) {
		this.producto = producto;
	}
	
	public Integer getVentaId() {
		return ventaId;
	}
	public void setVentaId(Integer ventaId) {
		this.ventaId = ventaId;
	}
	public Integer getProductoId() {
		return productoId;
	}
	public void setProductoId(Integer productoId) {
		this.productoId = productoId;
	}
	public Integer getCantidad() {
		return cantidad;
	}
	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}
}
