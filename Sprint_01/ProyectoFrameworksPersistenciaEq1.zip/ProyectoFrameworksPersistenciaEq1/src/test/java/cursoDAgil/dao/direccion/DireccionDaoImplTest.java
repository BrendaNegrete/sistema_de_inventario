/*
 * EQUIPO 01
 * AUTOR: ARMANDO VENTURA DOMINGUEZ
 */
package cursoDAgil.dao.direccion;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.*;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Direccion;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = {"/applicationContext.xml"})
public class DireccionDaoImplTest {
	@Inject
	DireccionDao direccionDao;
	
	@Test
	public void consultarDireccionPorId() {
		Direccion direccion = new Direccion();
		Map<String, Integer> mapDireccion = new HashMap<>();
		mapDireccion.put("idDireccion", 1);
		System.out.println("\nTEST PARA CONSULTAR UNA DIRECCIÓN POR ID");
		try {
			direccion = direccionDao.obtenerDireccionPorId(mapDireccion);
			assertNotNull(direccion);
			System.out.println("Id: " + direccion.getIdDireccion());
			System.out.println("Dirección: " + direccion.getCalle() + " " + direccion.getNumero()
				+ " " + direccion.getColonia() + ", " + direccion.getCiudad() + ", " + direccion.getEstado()
				+ ", " + direccion.getPais() + " CP." + direccion.getCodigoPostal());
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	@Test
	public void pruebaConsultarTodo() {
		int reg;
		System.out.println("\nTEST PARA CONSULTAR TODAS LAS DIRECCIONES");
		try {
			List<Direccion> lista = direccionDao.obtenerDirecciones();
			reg = lista.size();
			assertEquals(lista.size(), reg);
			System.out.println("Total de registros en la tabla: " + reg);
			for(Direccion d:lista) {
				System.out.println("\tId: " + d.getIdDireccion());
				System.out.println("\tDirección: " + d.getCalle() + " " + d.getNumero() + " " +
						d.getColonia() + ", " + d.getCiudad() + ", " + d.getEstado() + ", " +
						d.getPais() + " CP." + d.getCodigoPostal() + "\n");
			}
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	@Test
	public void nuevoRegistro() {
		Direccion direccion = new Direccion();
		
		System.out.println("Test nuevo registro");
		try {
			direccion.setCalle("Reforma");
			direccion.setNumero(3);
			direccion.setColonia("Centro");
			direccion.setCiudad("Huajuapan");
			direccion.setEstado("Oaxaca");
			direccion.setPais("México");
			direccion.setCodigoPostal(69000);
			direccionDao.nuevaDireccionCliente(direccion);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	@Test
	public void eliminarDireccionPorId() {
		Map<String, Integer> mapDireccion = new HashMap<>();
		mapDireccion.put("idDireccion", 2);
		System.out.println("\nTEST PARA ELIMINAR UNA DIRECCIÓN POR ID");
		try {
			direccionDao.eliminarDireccionPorId(mapDireccion);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	@Test
	public void actualizarDireccionCliente() {
		Direccion direccion = new Direccion();
		System.out.println("\nTest para actualizar registro");
		try {
			direccion.setIdDireccion(1);
			direccion.setCalle("Micaela Galindo");
			direccion.setNumero(3);
			direccion.setColonia("Centro");
			direccion.setCiudad("Huajuapan");
			direccion.setEstado("Oaxaca");
			direccion.setPais("México");
			direccion.setCodigoPostal(69000);
			direccionDao.actualizarDireccionCliente(direccion);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
}