/*
 * EQUIPO 01
 * AUTOR: DAVID GERMAN CASTRO ORTIZ
 */
package cursoDAgil.dao.ganancia;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Ganancia;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml"})
public class GananciaDaoImplTest {
	@Inject
	GananciaDao gananciaDao;
	
	@Test
	public void pruebaConsultarTodo() {
		System.out.println("\nTEST PARA CONSULTAR TODAS LAS GANANCIAS");
		try {
			List<Ganancia> lista = gananciaDao.listarGanancia();
			assertEquals(lista.size(), lista.size());
		}catch(Exception ex){
			System.out.println("Error" + ex);
		}
	}
	
	@Test
	public void pruebaListarPorFecha() {
		System.out.println("\nTEST PARA CONSULTAR UNA GANANCIA POR FECHA");
		Ganancia ganancia = new Ganancia();
		Map<String, String> mapGanancia = new HashMap<>();
		mapGanancia.put("fecha","2022-04-20");
		try{
			ganancia = gananciaDao.listarPorFecha(mapGanancia);
			assertNotNull(mapGanancia);
			
			System.out.println("\tFecha" + ganancia.getFecha());
			System.out.println("\tTotal ganancia" + ganancia.getTotalGanancia());
			System.out.println("\tId ganancia" + ganancia.getIdGanancia());
			System.out.println("\tId venta" + ganancia.getVentaId());
			System.out.println();
		}catch(Exception e){
			System.out.println("Error: " + e);
		}
	}

}