/*
 * EQUIPO 01
 * AUTOR: ALEJANDRA LOPEZ ROJAS
 */
package cursoDAgil.dao.producto;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Productos;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/applicationContext.xml"})
public class ProductoDaoImplTest {
	@Inject
	 ProductoDao productosDao;
		
	@Test
	public void ProductoxIdconDir() {
		Productos producto= new Productos();
		Map<String, Integer> mapProducto = new HashMap<>();
		mapProducto.put("idProducto", 1);
		System.out.println("\n CONSULTA DE UN PRODUCTO POR ID Y MOSTRAR MARCA");
		try {
			producto = productosDao.consultaProductoPorIdmosrarMarca(mapProducto);
			assertNotNull(producto);
			System.out.println("Id: " + producto.getIdProducto());
			System.out.println("Nombre del producto: " + producto.getNombre());
			System.out.println("Precio: " + producto.getPrecio());
			System.out.println("Precio Venta: " + producto.getPrecioVta());
			System.out.println("Cantidad: " + producto.getCantidad());
			System.out.println("Marca: " + producto.getMarca().getIdMarca());
			System.out.println("Nombre de la Marca: "+ producto.getMarca().getNombreMarca());
			
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}

	@Test
	public void modificarProducto() {
	    Productos productos= new Productos();
	    System.out.println("\nTEST PARA MODIFICAR PRODUCTO POR ID");
		productos.setIdProducto(1);
		productos.setNombre("Mayonesa de Chipotle de 800 gr");
		productos.setPrecio(25);
		productos.setPrecioVta(29);
		productos.setCantidad(40);
		productos.setMarcaId(1);
		productosDao.modificarProducto(productos);		
	}
	
	@Test
	public void eliminaProducto() throws Exception{
		//Productos producto= new Productos();
		Map<String, Integer> mapProductos = new HashMap<>();
		mapProductos.put("idProducto", 2);
		System.out.println("\nTEST ELEMINAR PRODUCTO");
		try {
			productosDao.eliminarProdcuto(mapProductos);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
    }
	
	@Test
	public void pruebaConsultarTodo() {
		System.out.println("\nTEST LISTAR TODOS LOS PRODUCTOS");
		try {
			List<Productos> lista = productosDao.listarProductos();
			int i = lista.size();
			assertEquals(lista.size(), i);
			for(Productos c:lista) {
				System.out.println("\tId: " + c.getIdProducto());
				System.out.println("\tNombre del Producto: " + c.getNombre() );
				System.out.println("\tPrecio: " + c.getPrecio());
				System.out.println("\tPrecio Venta: " + c.getPrecioVta());
				System.out.println("\tCantidad: " + c.getCantidad());
				System.out.println("\tMarca Id: " + c.getMarcaId());
			}
		}catch (Exception ex) {
			System.out.println("Error: " + ex);
		}
	}
	
	@Test
	public void RegistarProducto() {
		Productos producto= new Productos();
		
		System.out.println("Test nuevo registro");
		try {
			producto.setNombre("Coca-Cola  600 ml");
			producto.setCantidad(10);
			producto.setPrecio(16.9);
			producto.setPrecioVta(18);
			producto.setMarcaId(3);
			productosDao.nuevoProducto(producto);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}		
	
	@Test
	public void consultarProductonPorId() {
		Productos producto= new Productos();
		Map<String, Integer> mapProducto = new HashMap<>();
		mapProducto.put("idProducto", 4);
		System.out.println("\nTEST PARA CONSULTAR UN PRODUCTO POR SU ID");
		try {
			producto = productosDao.obtenerProductoPorId(mapProducto);
			assertNotNull(producto);
			System.out.println("Id: " + producto.getIdProducto());
			System.out.println("Nombre del producto: " + producto.getNombre());
			System.out.println("Precio: " + producto.getPrecio());
			System.out.println("Precio Venta: " + producto.getPrecioVta());
			System.out.println("Cantidad: " + producto.getCantidad());
			System.out.println("Marca: " + producto.getMarcaId());
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	@Test
	public void MostrarProductosM() {
		System.out.println("\nTEST PARA LISTAR TODOS LOS PRODUCTOS Y SUS MARCAS");
		try {
			List<Productos> lista = productosDao.listarProductosYmarcas();
			int i = lista.size();
			assertEquals(lista.size(), i);
			for(Productos c:lista) {
				System.out.println("\tIdProducto: " + c.getIdProducto());
				System.out.println("\tNombre del Producto: " + c.getNombre());
				System.out.println("\tPrecio: " + c.getPrecio());
				System.out.println("\tPrecio de Venta : " + c.getPrecioVta());
				System.out.println("\tCantidad: " + c.getCantidad());
				System.out.println("\t Marca ---->  " +c.getMarca().getIdMarca()+" "+ c.getMarca().getNombreMarca());
			}
		}catch (Exception ex) {
			System.out.println("Error: " + ex);
		}
	}	
}