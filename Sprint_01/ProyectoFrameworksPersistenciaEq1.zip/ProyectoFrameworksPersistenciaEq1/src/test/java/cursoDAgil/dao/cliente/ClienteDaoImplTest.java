/*
 * EQUIPO 01
 * AUTOR: ARMANDO VENTURA DOMINGUEZ
 */
package cursoDAgil.dao.cliente;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Cliente;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/applicationContext.xml"})
public class ClienteDaoImplTest {
	@Inject
	ClienteDao clienteDao;	
	
	@Test
	public void pruebaConsultarTodo() {
		int reg;
		System.out.println("\nTEST PARA CONSULTAR TODOS LOS CLIENTES");
		try {
			List<Cliente> lista = clienteDao.listarClientes();
			reg = lista.size();
			assertEquals(lista.size(), reg);
			for(Cliente c:lista) {
				System.out.println("\tId: " + c.getId());
				System.out.println("\tCliente: " + c.getNombre() + " " + c.getApellido() +
				", Email: " + c.getEmail() + ", " + "Sexo: " + c.getSexo() + ", idDireccion: " + c.getIdDireccion());				
			}
		}catch (Exception ex) {
			System.out.println("Error: " + ex);
		}
	}
	
	@Test
	public void insertarCliente() {
		Cliente cliente = new Cliente();
		System.out.println("\nTEST PARA INSERTAR CLIENTE");
		try {
			cliente.setNombre("Juanito");
			cliente.setApellido("Martinez");
			cliente.setEmail("fulano@gmail.com");
			cliente.setSexo("Masculino");
			cliente.setIdDireccion(1);
			clienteDao.insertarCliente(cliente);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	@Test
	public void eliminarClienteId() {
		Map<String, Integer> mapCliente = new HashMap<>();
		mapCliente.put("id", 6);
		System.out.println("\nTEST PARA ELIMINAR UN CLIENTE POR ID");
		try {
			clienteDao.eliminarCliente(mapCliente);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	@Test
	public void actualizarCliente() {
		Cliente cliente = new Cliente();
		System.out.println("\nTest para actualizar cliente");
		try {
			cliente.setId(1);
			cliente.setNombre("Fulanito");
			cliente.setApellido("Perez");
			cliente.setEmail("fula@hotmail");
			cliente.setSexo("Masculino");
			cliente.setIdDireccion(2);
			clienteDao.actualizarCliente(cliente);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	@Test
	public void obtenerClientePorId() {
		Cliente cliente = new Cliente();
		Map<String, Integer> mapCliente = new HashMap<>();
		mapCliente.put("id", 1);
		System.out.println("\nTEST PARA CONSULTAR UN CLIENTE POR ID");
		try {
			cliente = clienteDao.obtenerClientePorId(mapCliente);
			assertNotNull(cliente);
			System.out.println("\tId: " + cliente.getId());
			System.out.println("\tCliente: " + cliente.getNombre() + ", " + cliente.getApellido() +
			", Email: " + cliente.getEmail() + ", " + "Sexo: " + cliente.getSexo() + ", idDireccion: " + cliente.getIdDireccion());				

		} catch (Exception e) {
			System.out.println("Error: " + e);
		}

	}
	
	@Test
	public void listarClientesDireccion() {
		int reg;
		System.out.println("\nTEST PARA CONSULTAR TODOS LOS CLIENTES Y SUS DIRECCIONES");
		try {
			List<Cliente> lista = clienteDao.listarClientesDireccion();
			reg = lista.size();
			assertEquals(lista.size(), reg);
			for(Cliente c:lista) {
				System.out.println("\tId: " + c.getId());
				System.out.println("\tCliente: " + c.getNombre() + " " + c.getApellido());
				System.out.println("\tEmail: " + c.getEmail() + ", " + "Sexo: " + c.getSexo() + ", idDireccion: " + c.getIdDireccion());
				System.out.println("\tCalle " + c.getDireccion().getCalle() + ", Numero: " + c.getDireccion().getNumero() + " " + c.getDireccion().getColonia() + ", " +
						c.getDireccion().getCiudad() + ", " + c.getDireccion().getEstado() + ", " +
						c.getDireccion().getPais() + " CP." + c.getDireccion().getCodigoPostal() + "\n");
			}
		}catch (Exception ex) {
			System.out.println("Error: " + ex);
		}
	}
	
	@Test
	public void obtenerClienteDireccionPorId() {
		Cliente cliente = new Cliente();
		Map<String, Integer> mapCliente = new HashMap<>();
		mapCliente.put("id", 1);
		System.out.println("\nTEST PARA CONSULTAR UN CLIENTE CON SU DIRECCION POR ID");
		try {
			cliente = clienteDao.obtenerClienteDireccionPorId(mapCliente);
			assertNotNull(cliente);
			
			System.out.println("\tId: " + cliente.getId());
			System.out.println("\tCliente: " + cliente.getNombre() + " " + cliente.getApellido());
			System.out.println("\tEmail: " + cliente.getEmail() + ", " + "Sexo: " + cliente.getSexo() + ", idDireccion: " + cliente.getIdDireccion());
			System.out.println("\tCalle " + cliente.getDireccion().getCalle() + ", Numero: " + cliente.getDireccion().getNumero() + " " + cliente.getDireccion().getColonia() + ", " +
					cliente.getDireccion().getCiudad() + ", " + cliente.getDireccion().getEstado() + ", " +
					cliente.getDireccion().getPais() + " CP." + cliente.getDireccion().getCodigoPostal() + "\n");
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
}
