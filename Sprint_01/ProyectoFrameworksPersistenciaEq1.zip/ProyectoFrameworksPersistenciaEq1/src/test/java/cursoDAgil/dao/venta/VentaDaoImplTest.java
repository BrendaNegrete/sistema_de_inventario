/*
 * EQUIPO 01
 * AUTOR: DAVID GERMAN CASTRO ORTIIZ
 */
package cursoDAgil.dao.venta;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Ventas;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = {"/applicationContext.xml"})
public class VentaDaoImplTest {
	@Inject
	VentaDao ventaDao;
	
	@Test
	public void pruebaConsultarTodo() {
		int reg;
		System.out.println("\nTEST PARA LISTAR TODAS LAS VENTAS");
		try {
			List <Ventas> lista = ventaDao.listarTodasVentas();
			reg = lista.size();
			assertEquals(lista.size(), reg);
			System.out.println("Total de Ventas registradas en la Base de Datos: " + reg);
			for(Ventas v:lista) {
				System.out.println("\tId: " + v.getIdVenta());
				System.out.println("\tTotal: $" + v.getTotalVenta() + "\tFecha: " + v.getFecha());
				System.out.println("\tCliente: " + v.getClienteId());
				System.out.println("\tCliente: " + v.getCliente().getNombre() + " " + v.getCliente().getApellido() + "\n");
			}			
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	@Test
	public void consultarVentaPorId() {
		Ventas venta = new Ventas();
		
		Map<String, Integer> mapVenta = new HashMap<>();
		mapVenta.put("idVenta", 1240);
		
		System.out.println("\nTEST PARA CONSULTAR UNA VENTA POR ID");
		try {
			venta = ventaDao.obtenerVentaPorId(mapVenta);
			assertNotNull(mapVenta);
			System.out.println("\tId: " + venta.getIdVenta());
			System.out.println("\tTotal: $" + venta.getTotalVenta() + "\tFecha: " + venta.getFecha());
			System.out.println("\tCliente: " + venta.getClienteId());
			System.out.println("\tCliente: " + venta.getCliente().getNombre() + " " + venta.getCliente().getApellido() + "\n");
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	@Test
	public void consultarVentaPorCliente() {
		int i;
		
		Map<String, String> mapVenta = new HashMap<>();
		mapVenta.put("nombre", "Juanito");
		mapVenta.put("apellido", "Martinez");
		
		try {
			System.out.println("\nTEST PARA CONSULTAR VENTAS POR CLIENTE");
			List <Ventas> lista = ventaDao.obtenerVentasPorCliente(mapVenta);
			i = lista.size();
			assertEquals(lista.size(), i);
			for(Ventas venta:lista) {
				System.out.println("\tId: " + venta.getIdVenta());
				System.out.println("\tTotal: $" + venta.getTotalVenta() + "\tFecha: " + venta.getFecha());
				System.out.println("\tCliente: " + venta.getClienteId());
				System.out.println("\tCliente: " + venta.getCliente().getNombre() + " " + venta.getCliente().getApellido() + "\n");
			}	
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	@Ignore
	public void agregarNuevaVenta() {
		Ventas venta = new Ventas();
		
		System.out.println("\nTEST PARA CREAR UNA NUEVA VENTA");
		try {
			Date fecha = new Date(System.currentTimeMillis());
			venta.setClienteId(1);
			venta.setTotalVenta(3021.20);
			venta.setFecha(fecha);
			ventaDao.nuevaVenta(venta);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
}