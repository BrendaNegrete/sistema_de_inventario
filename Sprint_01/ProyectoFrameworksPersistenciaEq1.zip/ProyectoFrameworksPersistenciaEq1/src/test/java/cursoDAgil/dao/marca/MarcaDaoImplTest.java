/*
 * EQUIPO 01
 * AUTOR: BRENDA NEGRETE SANCHEZ
 */
package cursoDAgil.dao.marca;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.Marca;

@RunWith (SpringJUnit4ClassRunner.class)
@ContextConfiguration (locations = {"/applicationContext.xml"})
public class MarcaDaoImplTest {
	@Inject
	MarcaDao marcaDao;
	
	@Test
	public void nuevoRegistro() {
		Marca marca = new Marca();
		
		System.out.println("Test nuevo registro");
		try {
			marca.setNombreMarca("Bimbo");
			marcaDao.nuevaMarca(marca);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}

	
	@Test
	public void consultarMarca() {
		Marca marca = new Marca();
		Map<String, Integer> mapMarca = new HashMap<>();
		mapMarca.put("idMarca", 1);
		System.out.println("\nTEST PARA CONSULTAR UNA MARCA POR ID");
		try {
			marca = marcaDao.obtenerMarca(mapMarca);
			assertNotNull(marca);
			System.out.println("Id: " + marca.getIdMarca());
			System.out.println("Marca: " + marca.getNombreMarca());
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	@Test
	public void pruebaConsultarTodo() {
		int reg;
		System.out.println("\nTEST PARA CONSULTAR TODAS LAS MARCAS");
		try {
			List<Marca> lista = marcaDao.obtenerMarcas();
			reg = lista.size();
			assertEquals(lista.size(), reg);
			System.out.println("Total de registros en la tabla: " + reg);
			for(Marca d:lista) {
				System.out.println("\tId: " + d.getIdMarca());
				System.out.println("\tMarca: " + d.getNombreMarca() + "\n");
			}
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	
	@Test
	public void eliminarMarca() {
		Map<String, Integer> mapMarca = new HashMap<>();
		mapMarca.put("idMarca", 2);
		System.out.println("\nTEST PARA ELIMINAR UNA MARCA POR ID");
		try {
			 marcaDao.eliminarMarca(mapMarca);
			System.out.println("Eliminado");
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
	@Test
	public void modificarRegistro() {
		Marca marca = new Marca();
		
		System.out.println("Test modificar Marca");
		try {
			marca.setIdMarca(3);
			marca.setNombreMarca("Alpura");
			marcaDao.cambiarMarca(marca);
		} catch (Exception e) {
			System.out.println("Error: " + e);
		}
	}
}