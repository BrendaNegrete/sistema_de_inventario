/*
 * EQUIPO 01
 * AUTOR: DAVID GERMAN CASTRO ORTIZ
 */
package cursoDAgil.dao.detalleVenta;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import cursoDAgil.bd.domain.DetalleVenta;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/applicationContext.xml"})
public class DetalleVentaDaoImplTest {
	@Inject
	DetalleVentaDao detalleVentaDao;
		
	@Test
	public void pruebaConsultarVentas() {
		System.out.println("\nTEST PARA CONSULTAR TODOS LOS DETALLES DE UNA VENTA");
		try {
			List <DetalleVenta> lista = detalleVentaDao.listarTodosDetalleVentas();
			assertEquals(lista.size(), lista.size());
			
			for(DetalleVenta DV:lista) {
				System.out.println("\tVentaId: "+ DV.getVentaId());
				System.out.println("\tproductoId: "+ DV.getProductoId());
				System.out.println("\ttotalVenta: "+ DV.getCantidad());
				
				System.out.println("\tProducto ID: "+ DV.getProductos().getIdProducto());
				System.out.println("\t\tNombre: "+ DV.getProductos().getNombre());
				System.out.println("\t\tPrecio: "+ DV.getProductos().getPrecio());
				System.out.println("\t\tCantidad: "+ DV.getProductos().getCantidad());
				System.out.println("\t\tMarca Id: "+ DV.getProductos().getMarcaId());
			}
		} catch (Exception e) {
			System.out.println("Error" + e);
		}
	}
}